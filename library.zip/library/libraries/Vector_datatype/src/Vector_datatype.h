// Add header that matches library name. Required for compliane with arduino standard. 

#ifndef Vector_datatype_h
#define Vector_datatype_h

#include "quaternion_type.h"

#endif
